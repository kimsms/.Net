﻿using IvmUtils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class XtraForm1 : DevExpress.XtraEditors.XtraForm
    {
        private 모델자료 모델자료 = new 모델자료();

        public XtraForm1()
        {
            InitializeComponent();
            this.GridView1.Init(this.barManager1);
            this.GridView1.AddDeleteMenuItem(new ItemClickEventHandler(모델삭제));
            this.GridView1.OptionsBehavior.Editable = true;
            this.GridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.GridView1.OptionsView.ShowAutoFilterRow = true;
            this.Load += XtraForm1_Load;
        }

        private void XtraForm1_Load(object sender, EventArgs e)
        {
            this.GridControl1.DataSource = this.모델자료;
        }

        public void 모델삭제(object sender, ItemClickEventArgs e)
        {
            if (this.GridView1.FocusedRowHandle < 0) return;
            검사모델 row = (검사모델)this.GridView1.GetFocusedRow();// this.GridView1.GetRow(this.GridView1.GetDataSourceRowIndex(this.GridView1.FocusedRowHandle));
            if (row == null) return;
            if (!Utils.Confirm("선택한 모델을 삭제하시겠습니까?")) return;
            this.GridView1.DeleteRow(this.GridView1.FocusedRowHandle);
        }
    }
}