﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class 검사모델
    {
        public int 번호 { get; set; } = 0;
        public String 설명 { get; set; } = String.Empty;
        public Decimal 최소값 { get; set; } = 0m;
        public Decimal 최대값 { get; set; } = 0m;
        public String 단위 { get; set; } = String.Empty;
    }

    public class 모델자료 : BindingList<검사모델>
    {

    }
}
