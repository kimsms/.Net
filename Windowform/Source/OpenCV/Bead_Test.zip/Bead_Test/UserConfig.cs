﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bead_Test
{
    public class UserConfig
    {
        public string Setting_01 { get; set; }
        public string Setting_02 { get; set; }
        public string Setting_03 { get; set; }
        public string Setting_04 { get; set; }
        public string Setting_05 { get; set; }
        public string Setting_06 { get; set; }
        public string Setting_07 { get; set; }
        public string Setting_08 { get; set; }
        public string Setting_09 { get; set; }
        public string Setting_10 { get; set; }
        public string Setting_11 { get; set; }
        public string Setting_12 { get; set; }
        public string Setting_13 { get; set; }
        public string Setting_14 { get; set; }
        public string Setting_15 { get; set; }
        public string Setting_16 { get; set; }
        public string Setting_17 { get; set; }
        public string Setting_18 { get; set; }
        public string Setting_19 { get; set; }
        public string Setting_20 { get; set; }
    }
}
