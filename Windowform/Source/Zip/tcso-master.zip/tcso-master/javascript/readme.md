# TcSo Javascript
This is the javascript version of the Try catch stack overflow. Use the try catch block used in [tcso.js](tcso.js). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* A browser which supports javascript
* Popup blocking must be disabled

#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* {your-name-here}
