# TcSo Apex
This is the Apex version of Try-Catch StackOverflow. Apex is Salesforce's strongly typed, object-oriented programming language that uses syntax that looks like Java but runs in multitenant aware fashion. Note that the try-catch block in [tcso.apxc](tcso.apxc) can only be used in the context of Visualforce pages.

Please feel free to use this example in your projects. Don't forget to make improvements and submit a new pull request.

#### Credits
Developed by: [kaszy86](https://github.com/kaszy86/)

###### Contributors
* {your-name-here}