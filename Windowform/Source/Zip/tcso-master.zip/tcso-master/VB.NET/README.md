# TcSo VB.NET
This is the VB.NET version of the Try catch stack overflow. Use the try catch block used in [tcso.vb](tcso.vb). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* A VB.NET Visual Studio project.
* A Web browser

#### Credits
Developed by: [Ricky Manning](https://github.com/rickymanning/)

###### Contributors
