# TcSo F# #
This is the F# version of the Try catch stack overflow. Use the try catch block used in [tcso.fs](https://github.com/gautamkrishnar/tcso/blob/master/F%23/tcso.fs). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Credits
Developed by: [Valdas3](https://github.com/Valdas3)

###### Contributors
* {your-name-here}
