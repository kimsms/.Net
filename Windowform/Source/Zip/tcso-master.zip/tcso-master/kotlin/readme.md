# TcSo Kotlin
This is the kotlin version for android of the Try catch stack overflow. Use the try catch block used in [tcso_android.kt](tcso_android.kt). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* Create an android project on the android studio IDE
* Create an activity to include this code.
* Import android.net.Uri and android.os.Bundle libraries

#### Credits
Developed by: [Julio Cruz](https://github.com/juliocruz83/)

###### Contributors
* {your-name-here}
