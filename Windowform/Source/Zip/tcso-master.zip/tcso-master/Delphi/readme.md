# TcSo Delphi #
This is the Delphi version of the Try catch stack overflow. Delphi does not have try catch, it has try except. Use the try except block used in tcso.pas. You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* For Windows platform you can use all delphi versions
* For POSIX platforms is required Delphi 10.2 or newer 

#### Credits
Developed by: [Giordano Giaccaglia](https://github.com/GiordanoGiaccaglia/)

###### Contributors
* [Giordano Giaccaglia](https://github.com/GiordanoGiaccaglia/)