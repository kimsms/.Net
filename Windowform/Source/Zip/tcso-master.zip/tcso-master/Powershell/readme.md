# TcSo Powershell
This is the powershell version of the Try catch stack overflow. Use the try catch block used in [tcso.ps1](tcso.ps1). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* Powershell
* A web browser

#### Credits
Developed by: [Asher Dratel](https://github.com/I71)

###### Contributors
* {your-name-here}