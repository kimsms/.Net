# TcSo Angular
This is the Angular version of the Try catch stack overflow. Put the 'tcso' folder in you app folder and  import  the 'tcso'  module in your  'app.module.ts'. You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.
## Demo
Check out the demo [@Stackblitz](https://stackblitz.com/edit/angular-c2xpip)

#### Credits
Developed by: [Ankur](https://github.com/Iamakr/)
#### Requirements
Implemented using javascript so:
* A browser which supports javascript
* Popup blocking must be disabled

###### Contributors
* {your-name-here}