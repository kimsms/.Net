# TcSo Haskell
This is the Haskell version of the Try catch stack overflow. Use the try catch block used in [tcso.hs](tcso.hs). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Don't forget
* You can execute the script by running:
```
runhaskell tcso.hs
```

#### Credits
Developed by: [Alo Davi](https://github.com/alodavi)

###### Contributors
* 
