# TcSo Scala
Example of TCSO in Scala. Take care to avoid the need of using it ;)

#### Requirements
* an exception
* the message of the exception probably has to be easily URLfiable, special characters may not work 100% correctly

#### Credits and contributors
Developed by: [Zantyr](https://github.com/Zantyr/)
