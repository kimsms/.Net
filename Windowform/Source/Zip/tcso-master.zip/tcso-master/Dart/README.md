# TcSo Dart
This is the dart version of the Try Catch Stack Overflow.
Use the try catch block used in [tcso.dart](tcso.dart).
You can use it in your projects. 
Please don't forget to make improvements and submit a new pull request.

#### Requirements
* A browser which supports javascript
* Popup blocking must be disabled

#### Credits
Developed by: [Akassharjun](https://github.com/akassharjun/)

###### Contributors
