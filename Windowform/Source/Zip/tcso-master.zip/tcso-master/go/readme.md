# TcSo Go
This is the go version of the Try catch stack overflow. 
Golang does not have exceptions such as try/catch/finally blocks. It has strict error handling with functions. What I have attempted here is to get the error object and open browser to search stack overflow for the same. Please don't forget to make improvements and submit a new pull request.

#### Requirements
* GO should be installed
* import runtime library of go by running -- go get github.com/go-openapi/runtime

#### Credits
Developed by: [Shailja Agarwala](https://github.com/sagarwala)

###### Contributors
* {your-name-here}
