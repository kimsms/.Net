# TcSo Perl
This is the Perl version of the Try catch stack overflow. Use the try catch block used in [tcso.pl](tcso.pl). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.
#### Requirements
Uses perl Try::Tiny  module. Remember to include it in your code by using  `use Try:Tiny;` statement.
#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
*  [Peter Mayr](https://github.com/hatorikibble/)
