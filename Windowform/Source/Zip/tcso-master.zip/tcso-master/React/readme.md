# TcSo React
This is the React version of the Try catch stack overflow. Put the 'tcso' folder in you app folder and  import  the 'tcso'  module in your  'app.js'. You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.
## Demo
Check out the demo [@Codepen](https://codesandbox.io/s/new)

#### Credits
Developed by: [Facebook](https://reactjs.org/docs/getting-started.html)
#### Requirements
Implemented using javascript so:
* A browser which supports javascript
* Popup blocking must be disabled

###### Contributors
* {your-name-here}