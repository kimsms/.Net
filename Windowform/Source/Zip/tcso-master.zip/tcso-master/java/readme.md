# TcSo Java
This is the java version of the Try catch stack overflow. Use the try catch block used in [tcso.java](tcso.java). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Don't forget
* You must use `throws java.io.IOException` in functions for eg:
```java
public static void main(String[] args) throws java.io.IOException { 
    /* TCSO code here */ 
    }
```

#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* {your-name-here}
