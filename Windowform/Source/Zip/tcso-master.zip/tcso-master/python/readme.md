# TcSo Python
This is the Python version of the Try catch stack overflow. Use the try catch block used in [tcso.py](tcso.py). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* Python  webbrowser module. Use `import webbrowser` to import it into your projects

#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* [Adam Chainz](https://github.com/adamchainz):[Tidy python implementation #2](https://github.com/gautamkrishnar/tcso/pull/2)
