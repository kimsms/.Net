# TcSo Objective C
This is the Objective C version of the Try catch stack overflow. Use the try catch block used in [tcso.m](tcso.m). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.
#### Requirements
None
#### Notes
Needs testing... Not tested...
#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* {your-name-here}
