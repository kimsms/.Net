# TcSo VBScript
This is the VBScript version of the Try catch stack overflow. Use the try catch block used in [tcso.vbs](tcso.vbs). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* A browser which supports VBScript
* Popup blocking must be disabled

#### Credits
Developed by: {Gaurav Kumar Pandit}

###### Contributors
* <!--{contributors-if-any}-->
