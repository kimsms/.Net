# TcSo Node
This is the Node version of the Try catch stack overflow. Use the try catch block used in [tcso.js](tcso.js). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Requirements
* [Open](https://www.npmjs.com/package/open) npm package: `npm install open`

#### Credits
Developed by: [U-siro](https://github.com/U-siro)

###### Contributors
* <!--{contributors-if-any}-->
