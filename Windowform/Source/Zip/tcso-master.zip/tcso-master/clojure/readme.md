# TcSo Clojure
This is the Clojure version of the Try catch stack overflow. Use the try catch block used in [tcso.clj](tcso.clj). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* {your-name-here}
