# TcSo Vue.js
This is the Vue.js version of the Try catch stack overflow. Register this in your main.js. You can use it in your projects. Please don't forget to make improvements and submit a new pull request.

#### Requirements
* A browser which supports javascript
* Popup blocking must be disabled

#### Credits
Developed by: [vinmaster](https://github.com/vinmaster)

###### Contributors
* <!--{contributors-if-any}-->