# TcSo C# #
This is the C# version of the Try catch stack overflow. Use the try catch block used in [tcso.cs](https://github.com/gautamkrishnar/tcso/blob/master/C%23/tcso.cs). You can use it in your projects. Please don't forget to make  improvements and submit a new pull request.

#### Credits
Developed by: [Gautam krishna R](https://github.com/gautamkrishnar/)

###### Contributors
* [Valdas3](https://github.com/Valdas3)